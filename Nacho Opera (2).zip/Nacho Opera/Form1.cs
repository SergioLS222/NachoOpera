﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nacho_Opera
{
    public partial class FrmOperaciones : Form
    {
        public FrmOperaciones()
        {
            InitializeComponent();
        }

        private void btnSuma_Click(object sender, EventArgs e)
        {
            RealizarOperacion((num1, num2) => num1 + num2);
        }

        private void btmResta_Click(object sender, EventArgs e)
        {
            RealizarOperacion((num1, num2) => num1 - num2);
        }

        private void btnMulti_Click(object sender, EventArgs e)
        {
            RealizarOperacion((num1, num2) => num1 * num2);
        }

        private void btnDivis_Click(object sender, EventArgs e)
        {
            RealizarOperacion((num1, num2) =>
            {
                if (num2 == 0)
                {
                    MessageBox.Show("No se puede dividir por cero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return 0;
                }
                else
                {
                    return num1 / num2;
                }
            });
        }

        private void RealizarOperacion(Func<double, double, double> operacion)
        {
            if (double.TryParse(txtNum1.Text, out double num1) && double.TryParse(txtNum2.Text, out double num2))
            {
                double resultado = operacion(num1, num2);
                MessageBox.Show($"El resultado es: {resultado}", "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Por favor, ingrese números válidos en ambas cajas de texto.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnFinalizar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
